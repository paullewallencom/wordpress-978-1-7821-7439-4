<?php
/*
Template Name: Forum Sticky Topic
Template Post Type: wpwaf_topic
*/
<div> Hello Topics </div>

?>
